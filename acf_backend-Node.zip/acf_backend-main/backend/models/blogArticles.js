const mongoose = require("mongoose");

const newsSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    content: { type: String, required: true }, // Stores rich text as HTML
    imageUrl: { type: String }, // Optional: Image URL
    category: { type: String, required: true },
    description:{
      type:String,require:true
    },
    state:{
      type:String,
    },
    city:{
      type:String,
    }
    ,
  },
  { timestamps: true }
);

module.exports = mongoose.model("News", newsSchema);
