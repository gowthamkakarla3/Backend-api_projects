const mongoose = require("mongoose");

const volunteerSchema = new mongoose.Schema({
  volunteerId: { type: String, required: true, unique: true },
  firstName: { type: String, required: true },
  lastName: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  phone: { type: String, required: true },
  password: { type: String, required: true },
  confirmPassword: { type: String },
  gender: { type: String, enum: ["Male", "Female", "Other"], required: true },
  dob: { type: Date, required: true },
  profileImage: { type: String }, // URL or path to the profile image
  address: { type: String, required: true },
  state: { type: String, required: true },
  city: { type: String, required: true },
  aadharNumber: { type: String, required: true, unique: true },
  aadharCard: { type: String }, // URL or path to the Aadhar card image
  specialization: { type: String },
  occupation: { type: String },
  activityDetailsText: { type: String },
  activityDetailsPdf: { type: String }, // URL or path to the PDF file
  status: { type: String, enum: ["Pending", "Approved", "Rejected"], default: "Pending" },
  role: { type: String, default:"Volunter" },
  token:{
    type:String
  },
  createdBy: { type: String }, // Admin who created the volunteer entry
  updatedBy: { type: String }, // Admin who last updated the entry
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model("Volunteer", volunteerSchema);
