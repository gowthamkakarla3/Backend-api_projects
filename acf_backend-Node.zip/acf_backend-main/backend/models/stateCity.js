const mongoose = require("mongoose");

const stateSchema = new mongoose.Schema({
  state: { type: String, required: true, unique: true },
  id:{
    type:String
  },
  stateCode:{
    type:String
  }
});

const citySchema = new mongoose.Schema({
  name: { type: String, required: true },
  state: { type: mongoose.Schema.Types.ObjectId, ref: "State", required: true },
});

const State = mongoose.model("State", stateSchema);
const City = mongoose.model("City", citySchema);

module.exports = { State, City };
