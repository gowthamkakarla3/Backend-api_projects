const mongoose = require("mongoose");

const victimSchema = new mongoose.Schema({
  volunteerId: { type: String},
  firstName: { type: String, required: true },
  lastName: { type: String, required: true },
  email: { type: String, required: true },
  phone: { type: String, required: true },
  gender: { type: String, enum: ["Male", "Female", "Other"], required: true },
  dob: { type: Date, required: true },
  profileImage: { type: String }, // URL or path to the profile image
  address: { type: String },
  state: { type: String },
  city: { type: String },
  aadharNumber: { type: String, required: true, unique: true },
  aadharCard: { type: String }, // URL or path to the Aadhar card image
  specialization: { type: String },
  occupation: { type: String },
  caseDetails: { type: String },
  caseDetailsPdf: { type: String }, // URL or path to the PDF file
  createdBy: { type: String }, // Admin who created the volunteer entry
  updatedBy: { type: String }, // Admin who last updated the entry
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model("Victim", victimSchema);
