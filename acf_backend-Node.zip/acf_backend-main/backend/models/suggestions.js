const mongoose = require("mongoose");

const suggestionSchema = new mongoose.Schema({
    suggestionId: { type: String },
    firstName: { type: String, required: true },
    //   lastName: { type: String, required: true },
    email: { type: String },
    phone: { type: String },
    state: { type: String, required: true },
    city: { type: String, required: true },
    feedback: {
        type: String, required: true
    }
    ,
    createdBy: { type: String }, // Admin who created the volunteer entry
    updatedBy: { type: String }, // Admin who last updated the entry
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model("Suggestion", suggestionSchema);
