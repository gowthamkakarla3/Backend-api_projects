const { State, City } = require("../models/stateCity");

// ✅ Create a new state

exports.createStates = async (req, res) => {
  try {
    const { states } = req.body; // Expecting an array of states
    if (!states || !Array.isArray(states)) {
      return res.status(400).json({ message: "Invalid states array" });
    }

    // Ensure no state has a null name
    const validStates = states.filter(state => state.state);
    console.log(states)

    if (validStates.length === 0) {
      return res.status(400).json({ message: "No valid states provided" });
    }

    // Use insertMany with "ordered: false" to skip duplicates
    await State.insertMany(validStates, { ordered: false })
      .then(() => res.status(201).json({ message: "States added successfully" }))
      .catch((error) => {
        if (error.code === 11000) {
          return res.status(400).json({ message: "Some states already exist" });
        }
        res.status(500).json({ message: "Server error", error: error.message });
      });

  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};



// ✅ Get all states
exports.getAllStates = async (req, res) => {
  try {
    const states = await State.find();
    res.status(200).json(states);
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// ✅ Create a new city under a state
exports.createCity = async (req, res) => {
  try {
    const { name, stateId } = req.body;
    if (!name || !stateId) return res.status(400).json({ message: "City name and stateId are required" });

    const stateExists = await State.findById(stateId);
    if (!stateExists) return res.status(404).json({ message: "State not found" });

    const newCity = new City({ name, state: stateId });
    await newCity.save();

    res.status(201).json({ message: "City created successfully", city: newCity });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// ✅ Get all cities under a specific state
exports.getCitiesByState = async (req, res) => {
  try {
    const { stateId } = req.params;
    const cities = await City.find({ state: stateId });
    res.status(200).json(cities);
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};
