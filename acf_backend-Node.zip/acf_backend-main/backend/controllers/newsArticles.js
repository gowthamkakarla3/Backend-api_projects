const News = require("../models/blogArticles");
// ✅ Create a new news/article (Admin)
exports.createNews = async (req, res) => {
  try {
    const { title, content, imageUrl, category, state,city,description } = req.body;
    console.log(city)

    if (!title || !content || !category) {
      return res.status(200).json({ responseCode:400, message: "All required fields must be filled" });
    }

    const newNews = new News({
      title,
      content, // Rich text (HTML)
      imageUrl,
      description,
      category,
      state,
      city
    });

    await newNews.save();

    res.status(201).json({
      responseCode:200,
      message: "News/article created successfully",
      news: newNews,
    });
  } catch (error) {
    res.status(500).json({ responseCode:500, message: "Server error", error: error.message });
  }
};

// ✅ Get all news/articles
exports.getAllNews = async (req, res) => {
  try {
    const newsList = await News.find().sort({ createdAt: -1 });
    res.status(200).json({responseCode:200,newsList:newsList});
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// ✅ Get a single news/article by ID
// exports.getNewsById = async (req, res) => {
//   try {
//     const { id } = req.params;
//     const news = await News.findById(id);

//     if (!news) {
//       return res.status(404).json({ message: "News/article not found" });
//     }

//     res.status(200).json(news);
//   } catch (error) {
//     res.status(500).json({ message: "Server error", error: error.message });
//   }
// };

// ✅ Update news/article (Admin)
exports.updateNews = async (req, res) => {
  try {
    const { id } = req.body;
    const updates = req.body;

    const updatedNews = await News.findByIdAndUpdate(id, updates, { new: true, runValidators: true });

    if (!updatedNews) {
      return res.status(200).json({ responseCode:400, message: "News/article not found" });
    }

    res.status(200).json({
      responseCode:200,
      message: "News/article updated successfully",
      news: updatedNews,
    });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// ✅ Delete news/article (Admin)
exports.deleteNews = async (req, res) => {
  try {
    const { id } = req.body;
    const deletedNews = await News.findByIdAndDelete(id);

    if (!deletedNews) {
      return res.status(200).json({responseCode:400, message: "News/article not found" });
    }

    res.status(200).json({ responseCode:200, message: "News/article deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};
