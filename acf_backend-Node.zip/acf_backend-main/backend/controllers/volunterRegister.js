const Volunteer = require("../models/volunter");
const OTP = require("../models/otp");
const sendEmail = require("../middleware/mailSender");
const otpGenerator = require("otp-generator");
const bcrypt = require("bcrypt");
const { generateToken } = require("../middleware/authMiddleware");
const  State = require("../models/stateCity");

const statesData=[
  { "id": "1", "state": "Andhra Pradesh", "stateCode": "AP" },
  { "id": "2", "state": "Arunachal Pradesh", "stateCode": "AR" },
  { "id": "3", "state": "Assam", "stateCode": "AS" },
  { "id": "4", "state": "Bihar", "stateCode": "BR" },
  { "id": "5", "state": "Chhattisgarh", "stateCode": "CG" },
  { "id": "6", "state": "Goa", "stateCode": "GA" },
  { "id": "7", "state": "Gujarat", "stateCode": "GJ" },
  { "id": "8", "state": "Haryana", "stateCode": "HR" },
  { "id": "9", "state": "Himachal Pradesh", "stateCode": "HP" },
  { "id": "10", "state": "Jharkhand", "stateCode": "JH" },
  { "id": "11", "state": "Karnataka", "stateCode": "KA" },
  { "id": "12", "state": "Kerala", "stateCode": "KL" },
  { "id": "13", "state": "Madhya Pradesh", "stateCode": "MP" },
  { "id": "14", "state": "Maharashtra", "stateCode": "MH" },
  { "id": "15", "state": "Manipur", "stateCode": "MN" },
  { "id": "16", "state": "Meghalaya", "stateCode": "ML" },
  { "id": "17", "state": "Mizoram", "stateCode": "MZ" },
  { "id": "18", "state": "Nagaland", "stateCode": "NL" },
  { "id": "19", "state": "Odisha", "stateCode": "OR" },
  { "id": "20", "state": "Punjab", "stateCode": "PB" },
  { "id": "21", "state": "Rajasthan", "stateCode": "RJ" },
  { "id": "22", "state": "Sikkim", "stateCode": "SK" },
  { "id": "23", "state": "Tamil Nadu", "stateCode": "TN" },
  { "id": "24", "state": "Telangana", "stateCode": "TG" },
  { "id": "25", "state": "Tripura", "stateCode": "TR" },
  { "id": "26", "state": "Uttar Pradesh", "stateCode": "UP" },
  { "id": "27", "state": "Uttarakhand", "stateCode": "UK" },
  { "id": "28", "state": "West Bengal", "stateCode": "WB" }
]

exports.volunteerRegister = async (req, res) => {
    try {
        const { firstName, lastName, email, phone, password, confirmPassword, gender, dob, address, state, city, aadharNumber, role, createdBy } = req.body;

        if (!firstName || !lastName || !email || !phone || !password || !confirmPassword || !gender || !dob || !address || !state || !city || !aadharNumber || !role) {
            return res.status(200).json({ responseCode: 400, message: "All required fields must be filled" });
        }

        if (password !== confirmPassword) {
            return res.status(200).json({ responseCode: 400, message: "Passwords do not match" });
        }

        const volunteerExists = await Volunteer.findOne({ email });
        if (volunteerExists) {
            return res.status(200).json({ responseCode: 400, message: "Email already registered" });
        }

        // Check if OTP was verified
        const otpRecord = await OTP.findOne({ email });
        if (otpRecord) {
            return res.status(200).json({ responseCode: 400, message: "OTP verification is required before registration" });
        }

        const generateUniqueId = () => `IND-VOL-${Math.floor(1000 + Math.random() * 9000)}`;

        const volunteerId = generateUniqueId();
        const hashedPassword = await bcrypt.hash(password, 10);

        const newVolunteer = new Volunteer({
            volunteerId,
            firstName,
            lastName,
            email,
            phone,
            password: hashedPassword,
            gender,
            dob,
            address,
            state,
            city,
            aadharNumber,
            role,
            status: "Pending",
            createdBy,
            updatedBy: createdBy,
        });

        await newVolunteer.save();

        res.status(201).json({ responseCode: 200, message: "Volunteer registered successfully" });
    } catch (error) {
        res.status(500).json({ responseCode: 500, message: "Server error", error: error.message });
    }
};


// Get all volunteers
exports.getAllVolunteers = async (req, res) => {
  console.log(req.user)
    try {
      if (req.user.role === "admin") {
        // Admin can view all volunteers
        const volunteers = await Volunteer.find();
        return res.status(200).json(volunteers);
      } else {
        // Volunteers can only view their own details
        const volunteer = await Volunteer.findOne({ userId: req.user._id });
        if (!volunteer) {
          return res.status(404).json({ message: "Volunteer details not found" });
        }
        return res.status(200).json(volunteer);
      }
    } catch (error) {
      res.status(500).json({ message: "Server error", error: error.message });
    }
  
};

// Get volunteer by ID
exports.getVolunteerById = async (req, res) => {
  const { id } = req.body
  try {

    const volunteer = await Volunteer.findById(id);

    if (!volunteer) {
      return res.status(200).json({ responseCode: 200, message: "Volunteer not found" });
    }

    res.status(200).json(volunteer);
  } catch (error) {
    res.status(500).json({ responseCode: 500, message: "Server error", error: error.message });
  }
};

// Update volunteer
exports.updateVolunteer = async (req, res) => {
  try {
    const { id, ...updates } = req.body; // Extract ID and updates
    console.log(updates)

    if (!id) {
      return res.status(200).json({ responseCode: 200, message: "Volunteer ID is required" });
    }

    updates.updatedBy = req.body.updatedBy || "Admin"; // Track who updated it
    updates.updatedAt = Date.now(); // Update timestamp

    const updatedVolunteer = await Volunteer.findByIdAndUpdate(id, updates, {
      new: true, // Return updated document
      runValidators: true, // Ensure validation rules are applied
    });

    if (!updatedVolunteer) {
      return res.status(200).json({ responseCode: 200, message: "Volunteer not found" });
    }

    res.status(200).json({
      responseCode: 200,
      message: "Volunteer updated successfully",
      volunteer: updatedVolunteer,
    });
  } catch (error) {
    res.status(500).json({ responseCode: 500, message: "Server error", error: error.message });
  }
};


// Delete volunteer
exports.deleteVolunteer = async (req, res) => {
  try {
    const { id } = req.body;
    console.log(id)

    const deletedVolunteer = await Volunteer.findByIdAndDelete(id);

    if (!deletedVolunteer) {
      return res.status(404).json({ responseCode: 200, message: "Volunteer not found" });
    }

    res.status(200).json({ message: "Volunteer deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

exports.sendOtp = async (req, res) => {
    try {
        const { email } = req.body;

        if (!email) {
            return res.status(200).json({ responseCode: 200, message: "Email is required" });
        }
        // await State.insertMany(statesData);


        // Generate a 6-digit OTP
        const otp = otpGenerator.generate(6, { 
            digits: true
        });

        console.log(otp)
        // Remove any existing OTP for this email
        await OTP.deleteOne({ email });

        // Save new OTP in the database
        const newOtp = new OTP({ email, otp });
        await newOtp.save();

        // Send OTP via email
        const emailSent = await sendEmail(email, `Your OTP is: ${otp}`,otp);
        

        if (emailSent) {
            res.status(200).json({ responseCode: 200, message: "OTP sent successfully" });
        } else {
            res.status(200).json({ responseCode: 200, message: "Failed to send OTP" });
        }
    } catch (error) {
        res.status(500).json({ responseCode: 500, message: "Server error", error: error.message });
    }
};
exports.verifyOtp = async (req, res) => {
  try {
      const { email, otp } = req.body;

      if (!email || !otp) {
          return res.status(200).json({ responseCode: 400, message: "Email and OTP are required" });
      }

      // Check if OTP exists
      const validOtp = await OTP.findOne({ email, otp });

      if (!validOtp) {
          return res.status(200).json({ responseCode: 400, message: "Invalid or expired OTP" });
      }

      // Remove OTP after successful verification
      await OTP.deleteOne({ email });

      res.status(200).json({ responseCode: 200, message: "OTP verified successfully" });
  } catch (error) {
      res.status(500).json({ responseCode: 500, message: "Server error", error: error.message });
  }
};
exports.volunterLogin=async (req, res) => {
  try {
    const { email, password } = req.body;
    console.log(email,password)

    // Find user
    const user = await Volunteer.findOne({ email });
    if (!user) return res.status(200).json({ error: "Volunter not found" });
    console.log(user)

    // Check password
    const isMatch = await bcrypt.compare(password, user.password);
    console.log(isMatch)

    if (!isMatch) return res.status(200).json({ error: "Invalid credentials" });

    // Generate JWT
    const token = generateToken(user)
    console.log(token)
    user.token = token;  // Update the user instance, not the model
    await user.save();  // Save the updated token in the database
    

    console.log(token)

    res.json({role:"volunter", responseCode:200, message: "Login successful", token });
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
};


