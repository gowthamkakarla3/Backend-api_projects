const Complaint = require("../models/complaints");

exports.complaintRegister = async (req, res) => {
  try {
    const { 
      firstName,  email, phone,
       state, city,
       caseDetails, createdBy 
    } = req.body;


    // Validate input
    if (!firstName || !email || !phone || !state || !city || !caseDetails ) {
      return res.status(400).json({ message: "All required fields must be filled" });
    }

    const generateUniqueId = () => `IND-COM-${Math.floor(1000 + Math.random() * 9000)}`;


    const complaintId = generateUniqueId();

    const newVolunteer = new Complaint({
      complaintId,
      firstName,
      email,
      phone,
      state,
      city,
     caseDetails,
      createdBy,
      updatedBy: createdBy,
    });

    await newVolunteer.save();

    res.status(201).json({
      message: "Complaint registered successfully",
      volunteer: newVolunteer,
    });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// Get all volunteers
exports.getAllcomplaint = async (req, res) => {
  try {
    const complaints = await Complaint.find();
    res.status(200).json({ responseCode:200,complaints:complaints});
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// Get volunteer by ID
exports.getcomplaintById = async (req, res) => {
  try {
    const { id } = req.body;
    const volunteer = await Complaint.findById(id);
    
    if (!volunteer) {
      return res.status(404).json({ message: "Volunteer not found" });
    }

    res.status(200).json(volunteer);
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// Update volunteer
exports.updatecomplaint = async (req, res) => {
  try {
    const { id } = req.body;
    const updates = req.body;
    updates.updatedBy = req.body.updatedBy || "Admin"; // Track who updated it

    const updatedVolunteer = await Complaint.findByIdAndUpdate(id, updates, { new: true, runValidators: true });

    if (!updatedVolunteer) {
      return res.status(404).json({ message: "Volunteer not found" });
    }

    res.status(200).json({
      message: "Volunteer updated successfully",
      volunteer: updatedVolunteer,
    });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// Delete volunteer
exports.deletecomplaint = async (req, res) => {
  try {
    const { id } = req.body;
    const deletedVolunteer = await Complaint.findByIdAndDelete(id);

    if (!deletedVolunteer) {
      return res.status(404).json({ message: "Volunteer not found" });
    }

    res.status(200).json({ message: "Volunteer deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};
