const { response } = require("express");
const Gallery = require("../models/gallery");

// ✅ Create a new gallery item (Admin)
exports.createGallery = async (req, res) => {
  try {
    const { title, Url,type, description } = req.body;

    if (!title || !type|| !Url || !description) {
      return res.status(200).json({responseCode:200, message: "All required fields must be filled" });
    }

    const newGalleryItem = new Gallery({
      title,
      Url,
      type,
      description,
    });

    await newGalleryItem.save();

    res.status(201).json({
      responseCode:200,
      message: "Gallery item created successfully",
      galleryItem: newGalleryItem,
    });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// ✅ Get all gallery items
exports.getAllGalleryItems = async (req, res) => {
  try {
    const galleryItems = await Gallery.find().sort({ createdAt: -1 });
    res.status(200).json({responseCode:200,galleryItems:galleryItems});
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// ✅ Get a single gallery item by ID


// ✅ Update gallery item (Admin)
exports.updateGalleryItem = async (req, res) => {
  try {
    const { id } = req.body;
    const updates = req.body;

    const updatedGalleryItem = await Gallery.findByIdAndUpdate(id, updates, { new: true, runValidators: true });

    if (!updatedGalleryItem) {
      return res.status(200).json({ responseCode:200, message: "Gallery item not found" });
    }

    res.status(200).json({
      responseCode:200,
      message: "Gallery item updated successfully",
      galleryItem: updatedGalleryItem,
    });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// ✅ Delete gallery item (Admin)
exports.deleteGalleryItem = async (req, res) => {
  try {
    const { id } = req.body;
    const deletedGalleryItem = await Gallery.findByIdAndDelete(id);

    if (!deletedGalleryItem) {
      return res.status(200).json({responseCode:200, message: "Gallery item not found" });
    }

    res.status(200).json({responseCode:200, message: "Gallery item deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};
