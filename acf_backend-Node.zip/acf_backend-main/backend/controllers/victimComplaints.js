const Victim = require("../models/victimComplaints");

exports.victimRegister = async (req, res) => {
  try {
    const { 
      firstName, lastName, email, phone, gender, 
      dob, profileImage, address, state, city, aadharNumber, aadharCard, 
      specialization, occupation,  
      CaseDetails,caseDetailsPdf,
        createdBy 
    } = req.body;

    console.log(firstName, lastName, email, phone);

    // Validate inputy
    if (!firstName || !lastName || !email || !phone || !gender || !dob || !address || !state || !city || !aadharNumber ) {
      return res.status(400).json({ message: "All required fields must be filled" });
    }

  

    // Generate a unique volunteer ID
    const generateUniqueId = () => {
      const randomDigits = Math.floor(1000 + Math.random() * 9000); // Generates a 4-digit random number
      return `IND-VIC-${randomDigits}`;
    };
    const volunteerId = generateUniqueId();

    const newVolunteer = new Victim({
      volunteerId,
      firstName,
      lastName,
      email,
      phone,
      gender,
      dob,
      profileImage,
      address,
      state,
      city,
      aadharNumber,
      aadharCard,
      specialization,

      occupation,
      createdBy,
      updatedBy: createdBy,
    });

    await newVolunteer.save();

    res.status(201).json({
      message: "Victim registered successfully",
      volunteer: newVolunteer,
    });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// Get all volunteers
exports.getAllVicitim = async (req, res) => {
  try {
    const volunteers = await Victim.find();
    res.status(200).json(volunteers);
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// Get volunteer by ID
exports.getVictimById = async (req, res) => {
  try {
    const { id } = req.params;
    const volunteer = await Victim.findById(id);
    
    if (!volunteer) {
      return res.status(404).json({ message: "Volunteer not found" });
    }

    res.status(200).json(volunteer);
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// Update volunteer
exports.updateVictim = async (req, res) => {
  try {
    const { id } = req.body;
    const updates = req.body;
    updates.updatedBy = req.body.updatedBy || "Admin"; // Track who updated it

    const updatedVolunteer = await Victim.findByIdAndUpdate(id, updates, { new: true, runValidators: true });

    if (!updatedVolunteer) {
      return res.status(404).json({ message: "Volunteer not found" });
    }

    res.status(200).json({
      message: "Victim updated successfully",
      volunteer: updatedVolunteer,
    });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// Delete volunteer
exports.deleteVictim = async (req, res) => {
  try {
    const { id } = req.body;
    const deletedVolunteer = await Victim.findByIdAndDelete(id);

    if (!deletedVolunteer) {
      return res.status(404).json({ message: "Victim not found" });
    }

    res.status(200).json({ message: "Victim deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};
