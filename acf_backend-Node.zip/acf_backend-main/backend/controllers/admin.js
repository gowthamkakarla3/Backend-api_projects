const bcrypt = require("bcrypt");
const User = require("../models/admin");
const {generateToken }= require("../middleware/authMiddleware");
const { response } = require("express");


// Register (Admin or Sub-Admin)
exports.adminRegister = async (req, res) => {
  try {
    const { name, email, password, role } = req.body;

    // Check if user exists
    const existingUser = await User.findOne({ email });
    if (existingUser) return res.status(200).json({ error: "Admin already exists" });

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create new user
    const newUser = new User({ name, email, password: hashedPassword, role });
    await newUser.save();

    res.status(201).json({ responseCode:200, message: "Admin registered successfully" });
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
}

// Login
exports.adminLogin=async (req, res) => {
  try {
    const { email, password } = req.body;
    console.log(email,password)

    // Find user
    const user = await User.findOne({ email });
    if (!user) return res.status(200).json({ responseCode:200,  message: "Admin not found" });
    console.log(user)

    // Check password
    const isMatch = await bcrypt.compare(password, user.password);
    console.log(isMatch)

    if (!isMatch) return res.status(200).json({ message: "Invalid credentials" });

    // Generate JWT
    const token = generateToken(user)
    console.log(token)
    user.token = token;  // Update the user instance, not the model
await user.save();  // Save the updated token in the database


    res.json({ role:"admin", responseCode:200, message: "Login successful", token });
  } catch (error) {
    res.status(200).json({ message: "Internal server error" });
  }
};

// Protected Route (Example)
// router.get("/admin-dashboard", authMiddleware, async (req, res) => {
//   if (req.user.role !== "admin") return res.status(200).json({ error: "Access denied" });

//   res.json({ message: "Welcome to Admin Dashboard" });
// });

// module.exports = router;

