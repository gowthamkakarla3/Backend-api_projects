const Suggestion = require("../models/suggestions");

exports.suggestionRegister = async (req, res) => {
  try {
    const { 
      firstName,  email, phone,
       state, city,
       feedback, createdBy 
    } = req.body;


    // Validate input
    if (!firstName || !email || !phone || !state || !city || !feedback ) {
      return res.status(400).json({ message: "All required fields must be filled" });
    }

  

    const generateUniqueId = () => `IND-SUG-${Math.floor(1000 + Math.random() * 9000)}`;


    const suggestionId = generateUniqueId();

    const newVolunteer = new Suggestion({
      suggestionId,
      firstName,
      email,
      phone,
      state,
      city,
     feedback,
      createdBy,
      updatedBy: createdBy,
    });

    await newVolunteer.save();

    res.status(201).json({ 
      responseCode:200,
      message: "Suggestion registered successfully",
      suggestions: newVolunteer,
    });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// Get all volunteers
exports.getAllSuggestion = async (req, res) => {
  try {
    const suggestions = await Suggestion.find();
    res.status(200).json({responseCode:200,suggestions:suggestions});
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// Get volunteer by ID
// exports.getSuggestionById = async (req, res) => {
//   try {
//     const { id } = req.params;
//     const volunteer = await Victim.findById(id);
    
//     if (!volunteer) {
//       return res.status(404).json({ message: "Volunteer not found" });
//     }

//     res.status(200).json(volunteer);
//   } catch (error) {
//     res.status(500).json({ message: "Server error", error: error.message });
//   }
// };

// Update volunteer
exports.updateSuggestion = async (req, res) => {
  try {
    const { id } = req.body;
    const updates = req.body;
    updates.updatedBy = req.body.updatedBy || "Admin"; // Track who updated it

    const updatedVolunteer = await Suggestion.findByIdAndUpdate(id, updates, { new: true, runValidators: true });

    if (!updatedVolunteer) {
      return res.status(200).json({ responseCode:200, message: "Suggestion not found" });
    }

    res.status(200).json({
      responseCode:200,
      message: "Suggestion updated successfully",
      suggestion: updatedVolunteer,
    });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// Delete volunteer
exports.deleteSuggestion = async (req, res) => {
  try {
    const { id } = req.body;
    const deletedVolunteer = await Suggestion.findByIdAndDelete(id);

    if (!deletedVolunteer) {
      return res.status(200).json({responseCode:200, message: "Suggestion not found" });
    }

    res.status(200).json({ responseCode:200, message: "Suggestion deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};
