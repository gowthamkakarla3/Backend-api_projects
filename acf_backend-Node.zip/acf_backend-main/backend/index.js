const express = require('express');
const connectDB = require('./db');
const app = express();
const cors = require('cors'); // Import CORS

const authRoutes=require("./Routes/route")
// Connect to the database
connectDB();

// Middleware to parse JSON
app.use(cors()); // Enable CORS

app.use(express.json());

// Routes
app.use('/', authRoutes);

// Start the server
const PORT = process.env.PORT || 3007;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
