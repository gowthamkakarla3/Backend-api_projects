const express = require('express');
const router = express.Router();
const {
  volunteerRegister,
  getAllVolunteers,
  updateVolunteer,
  deleteVolunteer,
  sendOtp,
  verifyOtp,
  volunterLogin,
} = require("../controllers/volunterRegister");
const { victimRegister, getAllVicitim, updateVictim,deleteVictim } = require('../controllers/victimComplaints');
const { complaintRegister, getAllcomplaint, updatecomplaint, deletecomplaint } = require('../controllers/compaint');
const { adminRegister, adminLogin } = require('../controllers/admin');
const { verifyToken } = require('../middleware/authMiddleware');
const { suggestionRegister, getAllSuggestion, updateSuggestion, deleteSuggestion } = require('../controllers/suggestion');
const { createGallery, getAllGalleryItems, updateGalleryItem, deleteGalleryItem } = require('../controllers/gallery');
const { createNews, getAllNews, updateNews, deleteNews } = require('../controllers/newsArticles');
const { createStates } = require('../controllers/stateCity');


// admin
router.post("/register",  adminRegister)
router.post("/adminlogin",adminLogin)
// volunter
router.post("/volunter_register",   volunteerRegister)
router.get("/all_volunter", verifyToken, getAllVolunteers)
router.put("/volunter_update",  updateVolunteer)
router.delete("/volunter_delete", deleteVolunteer)
router.post("/sendOtp",sendOtp)
router.post("/verifyOtp",verifyOtp)
router.post("/volunterlogin",volunterLogin)

//victim or complaints

router.post("/victim_register", victimRegister)
router.get("/all_victim", getAllVicitim)
router.put("/victim_update", updateVictim)
router.delete("/victim_delete", deleteVictim)

//compalints

router.post("/complaint_register", complaintRegister)
router.get("/all_compaint", getAllcomplaint)
router.put("/complaint_update", updatecomplaint)
router.delete("/complaint_delete", deletecomplaint)


//suggestion

router.post("/suggestion_register", suggestionRegister)
router.get("/all_suggestion", getAllSuggestion)
router.put("/suggestion_update", updateSuggestion)
router.delete("/suggestion_delete", deleteSuggestion)

//gallery
router.post("/add_images", createGallery)
router.post("/add_videos", createGallery)
router.get("/all_gallery", getAllGalleryItems)
router.put("/update_gallery", updateGalleryItem)
router.delete("/delete_gallery", deleteGalleryItem)

//news&articles
router.post("/add_news", createNews)
router.get("/all_news", getAllNews)
router.put("/update_news", updateNews)
router.delete("/delete_news", deleteNews)

//other
router.post("/state",createStates)


module.exports = router;
