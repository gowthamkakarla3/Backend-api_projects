const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const Admin = require('../models/admin');
const { response } = require('express');
const volunter = require('../models/volunter');


const JWT_SECRET = "mySuperSecretKey123!";

const generateToken = (user) => {
  const payload = {
    id: user._id,
    role: user.role,
  };

  return jwt.sign(payload, JWT_SECRET, { expiresIn: '1d' });
};

const validateCredentials = async (phone, password,role) => {
  const user = await Admin.findOne({ phone,role });

  if (!user) return null;

  const isPasswordValid = await bcrypt.compare(password, user.password);
  if(role !==user.role) return null 
  if (!isPasswordValid) return null;

  return user;
};

// Middleware to verify JWT token
const verifyToken = async (req, res, next) => {
  let token = req.headers.authorization; // Change const to let

  if (!token || !token.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Access Denied: No Token Provided" });
  }

  token = token.replace("Bearer ", "").trim(); // ✅ Now reassigning is allowed

  console.log("Extracted Token:", token); // Debugging log

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    console.log("Decoded Token:", decoded); // Debugging log

    // const user = await volunter.findById(decoded.id);
    // if (!user) {
    //   return res.status(404).json({ error: "User not found" });
    // }

    req.user = decoded;
    next();
  } catch (error) {
    console.error("Token Verification Error:", error.message); // Debugging log
    return res.status(403).json({ error: "Invalid or Expired Token" });
  }
};

// Middleware to check if user is an Admin
const isAdmin = (req, res, next) => {
  if (req.user.role !== "admin") {
    return res.status(200).json({ responseCode:403, message: "Access Denied: Admins Only" });
  }
  next();
};

// Middleware to check if user is a Hardware
// const isHardware = (req, res, next) => {
//   if (req.user.role !== "hardware") {
//     return res.status(403).json({ error: "Access Denied: Hardware Only" });
//   }
//   next();
// };

// // Middleware to check if user is a Chef
// const isChef = (req, res, next) => {
//   if (req.user.role !== "chef") {
//     return res.status(403).json({ error: "Access Denied: Chefs Only" });
//   }
//   next();
// };



module.exports = { generateToken, validateCredentials , verifyToken, isAdmin,};
